<?php include 'get_db_connection.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Show Data</title>
</head>
<body>
    <div class="container mt-4">
        <button class="btn btn-primary mb-3">
            <a href="product_form.php" class="text-light text-decoration-none">Add Product</a>
        </button>

        <form id="productForm" action="generate_pdf.php" method="post">
            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: Yellow">
                        <th class="text-center">Select</th>
                        <th class="text-center">ID</th>
                        <th class="text-center">Product</th>
                        <th class="text-center">Description</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM productmaster";
                    $result = mysqli_query($conn, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<tr>
                                <td class="text-center"><input type="checkbox" name="selected_products[]" value="'.$row['id'].'"></td>
                                <td>'.$row['id'].'</td>
                                <td>'.$row['name'].'</td>
                                <td>'.$row['description'].'</td>
                                <td>'.$row['price'].'</td>
                                <td>
                                    <button class="btn btn-primary">
                                        <a href="product_update.php?updateid='.$row['id'].'" class="text-light text-decoration-none">Edit</a>
                                    </button>
                                    <button class="btn btn-danger">
                                        <a href="delete.php?deleteid='.$row['id'].'" class="text-light text-decoration-none">Delete</a>
                                    </button>
                                </td>
                            </tr>';
                        }
                    }
                    ?>
                </tbody>
            </table>

            <!-- PDF Generate Button -->
            <button type="submit" class="btn btn-success" id="generateBill" style="display: none;">Generate Bill PDF</button>
        </form>
    </div>

    <script>
        // Show the "Generate Bill" button only if at least one checkbox is selected
        document.querySelectorAll("input[name='selected_products[]']").forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                let selected = document.querySelectorAll("input[name='selected_products[]']:checked").length;
                document.getElementById('generateBill').style.display = selected > 0 ? 'block' : 'none';
            });
        });
    </script>
</body>
</html>
