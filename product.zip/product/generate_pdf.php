<?php
include 'get_db_connection.php';
require_once('tcpdf/tcpdf.php');

// Fetch the last serial number from the database
$sql = "SELECT MAX(serial_number) AS last_serial FROM invoices";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$last_serial = $row['last_serial'] ?? 0;

// Increment Serial Number
$new_serial_number = $last_serial + 1;

// Format Serial Number (Demo/2024 - 2025/000XXX)
$formatted_serial = "Demo/2024 - 2025/" . str_pad($new_serial_number, 3, '0', STR_PAD_LEFT);

// Get the current date
$current_date = date('d-m-Y');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['selected_products'])) {
    $selected_ids = implode(",", $_POST['selected_products']);
    
    $sql = "SELECT name, price FROM productmaster WHERE id IN ($selected_ids)";
    $result = mysqli_query($conn, $sql);

    $products = [];
    $total = 0;

    while ($row = mysqli_fetch_assoc($result)) {
        $row['price'] = floatval($row['price']);
        $products[] = $row;
        $total += $row['price'];
    }

    // Custom PDF Class to Set Header with Logo & Styling
    class MYPDF extends TCPDF {
        public function Header() {
            // Background Blue
            $this->SetFillColor(0, 102, 255); // Blue Color (RGB)
            $this->Rect(0, 0, 210, 30, 'F'); // Full width background

            // Logo
            $logo = 'demoo.jpg'; // Ensure logo file is in the same directory
            $this->Image($logo, 85, 5, 40); // Adjust position (X, Y) and size

            // Thick Red Line below Logo
            $this->SetDrawColor(255, 0, 0); // Red
            $this->SetLineWidth(1.5); // Thick Line
            $this->Line(10, 30, 200, 30); // Line from (X1, Y1) to (X2, Y2)
            
            $this->Ln(20); // Space after header
        }
    }

    // Create PDF
    $pdf = new MYPDF();
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetTitle("Invoice");
    $pdf->SetHeaderData('', '', '', '');
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP + 15, PDF_MARGIN_RIGHT);
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

    // ✅ Use 'dejavusans' font to support ₹ symbol and emoji
    $pdf->SetFont('dejavusans', '', 12);
    $pdf->AddPage();

    // Title (Centered)
    $pdf->SetFont('dejavusans', 'B', 16);
    $pdf->Cell(0, 10, 'Product Invoice', 0, 1, 'C');

    // Serial Number & Date (Bold, Left & Right)
    $pdf->SetFont('dejavusans', 'B', 12);
    $pdf->Cell(0, 10, 'S.No: ' . $formatted_serial, 0, 0, 'L');  // Serial Number Left
    $pdf->Cell(0, 10, 'Date: ' . $current_date, 0, 1, 'R');  // Date Right
    $pdf->Ln(5); // Line Break

    // Table Header & Content
    $html = '<table border="1" cellspacing="0" cellpadding="6" style="width:100%; border-collapse:collapse;">
                 <thead>
                     <tr style="background-color: #f2f2f2; font-weight: bold; text-align: center;">
                         <th style="border: 1px solid black;">S.No</th>
                         <th style="border: 1px solid black;">Product</th>
                         <th style="border: 1px solid black;">Price (₹)</th>
                     </tr>
                 </thead>
                 <tbody>';

    // Table rows (Normal text)
    foreach ($products as $index => $product) {
        $html .= '<tr>
                    <td style="border: 1px solid black; text-align: center;">'.($index + 1).'</td>
                    <td style="border: 1px solid black; text-align: center;">'.$product['name'].'</td>
                    <td style="border: 1px solid black; text-align: center;">₹'.number_format($product['price'], 2).'</td>
                  </tr>';
    }

    // Total row (Bold)
    $html .= '<tr style="font-weight: bold;">
                <td colspan="2" style="border: 1px solid black; text-align: center;">Total</td>
                <td style="border: 1px solid black; text-align: center;">₹'.number_format($total, 2).'</td>
              </tr>';
    $html .= '</tbody></table>';

    // Add Table to PDF
    $pdf->writeHTML($html, true, false, true, false, '');

    $pdf->Ln(10);
    $pdf->SetFont('dejavusans', 'B', 14);
    $pdf->Cell(0, 10, 'Thank You!!!!! 😊', 0, 1, 'C');

    // ✅ Save new invoice serial number in the database
    $insert_sql = "INSERT INTO invoices (serial_number, created_at) VALUES ('$new_serial_number', NOW())";
    mysqli_query($conn, $insert_sql);

    // Output PDF
    $pdf->Output('invoice.pdf', 'D');
} else {
    echo "No products selected!";
}

?>
