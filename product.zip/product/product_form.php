<?php
session_start();
include 'get_db_connection.php';

if (isset($_POST['productsubmit'])) {

    $name         = htmlspecialchars(trim($_POST['name']));
    $description  = htmlspecialchars(trim($_POST['description']));
    $price        = trim($_POST['price']);
   
    $createddate = date('Y-m-d H:i:s');

    $query_check = "SELECT * FROM productmaster WHERE name = '$name'";
    $result_check = mysqli_query($conn, $query_check);

    if (mysqli_num_rows($result_check) > 0) {
        $_SESSION['status_failed'] = "Product Name already exists. Please choose another.";
        header('location: product_form.php');  
        exit;
    } else {
        // Insert new Product into the database
        $query_insert = "INSERT INTO productmaster (name, description, price, createddate, createdby, updateddate, updatedby) 
                         VALUES ('$name', '$description', '$price', '$createddate', 'admin', '$createddate', 'admin')";
                         
        if (mysqli_query($conn, $query_insert)) {
            $_SESSION['status_success'] = "Product Name successfull.";
            header('location: product_form.php');  
            exit;
        } else {
            $_SESSION['status_failed'] = "Product Name failed. Please try again.";
            header('location: product_form.php'); 
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details Form</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3 class="text-center">Product Details</h3>

                <?php
                if (isset($_SESSION['status_success'])) {
                    echo "<div class='alert alert-success'>".$_SESSION['status_success']."</div>";
                    unset($_SESSION['status_success']);
                }

                if (isset($_SESSION['status_failed'])) {
                    echo "<div class='alert alert-danger'>".$_SESSION['status_failed']."</div>";
                    unset($_SESSION['status_failed']);
                }
                ?>

                <!-- Product Details Form -->
                <form method="POST">
                    <div class="form-group">
                        <label for="nameid">Product Name</label>
                        <input type="text" class="form-control" id="nameid" name="name" placeholder="Enter product name" required>
                    </div>

                    <div class="form-group mt-3">
                        <label for="description">Description</label>
                        <textarea class="form-control" id="description" name="description" placeholder="Enter product description" rows="4" required></textarea>
                    </div>

                    <div class="form-group mt-3">
                        <label for="price">Price</label>
                        <input type="number" class="form-control" id="price" name="price" placeholder="Enter product price" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block mt-4" name="productsubmit">Submit</button>
                </form>
                <div class="text-center mt-3">
                    <a href="show.php">View All Products</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
