<?php 

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "crud";

$conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

?>